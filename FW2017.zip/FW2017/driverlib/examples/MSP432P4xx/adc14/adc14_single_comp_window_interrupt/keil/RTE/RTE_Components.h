
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'adc14_single_comp_window_interrupt' 
 * Target:  'adc14_single_comp_window_interrupt' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


#endif /* RTE_COMPONENTS_H */

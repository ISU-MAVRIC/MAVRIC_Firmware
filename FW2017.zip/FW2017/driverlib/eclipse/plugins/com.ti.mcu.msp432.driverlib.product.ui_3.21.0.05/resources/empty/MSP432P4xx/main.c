#include "driverlib.h"

int main(void) 
{
    WDT_A_holdTimer();

    while(1);
}

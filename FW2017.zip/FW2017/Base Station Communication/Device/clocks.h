/*
 * clocks.h
 *
 *  Created on: Sep 3, 2016
 *      Author: James
 */

#ifndef DEVICE_CLOCKS_H_
#define DEVICE_CLOCKS_H_

#define fACLK 32768ul
#define fSMCLK (48*1000000ull)
#define fMCLK (48*1000000ull)

#endif /* DEVICE_CLOCKS_H_ */
